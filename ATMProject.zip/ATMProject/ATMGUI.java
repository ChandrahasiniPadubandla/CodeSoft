import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;

class BankAccount {
    private double balance;

    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    public boolean deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            return true;
        }
        return false;
    }

    public boolean withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            return true;
        }
        return false;
    }

    public double getBalance() {
        return balance;
    }
}

class ATM {
    private BankAccount account;

    public ATM(BankAccount account) {
        this.account = account;
    }

    public boolean withdraw(double amount) {
        return account.withdraw(amount);
    }

    public boolean deposit(double amount) {
        return account.deposit(amount);
    }

    public double checkBalance() {
        return account.getBalance();
    }
}

public class ATMGUI {
    private JFrame frame;
    private JTextField amountField;
    private JLabel balanceLabel;
    private ATM atm;

    public ATMGUI() {
        atm = new ATM(new BankAccount(1000)); // Initial balance of $1000
        initialize();
    }

    private void initialize() {
        frame = new JFrame("ATM");
        frame.setBounds(100, 100, 450, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Set background color
        frame.getContentPane().setBackground(new Color(240, 240, 240));

        balanceLabel = new JLabel("Current Balance: $" + atm.checkBalance());
        balanceLabel.setHorizontalAlignment(SwingConstants.CENTER);
        balanceLabel.setFont(new Font("Arial", Font.BOLD, 16));
        balanceLabel.setForeground(new Color(0, 102, 204));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        frame.getContentPane().add(balanceLabel, gbc);

        JButton btnCheckBalance = new JButton("Check Balance");
        btnCheckBalance.setFont(new Font("Arial", Font.PLAIN, 14));
        btnCheckBalance.setBackground(new Color(102, 178, 255));
        btnCheckBalance.setForeground(Color.WHITE);
        btnCheckBalance.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                updateBalance();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        frame.getContentPane().add(btnCheckBalance, gbc);

        amountField = new JTextField();
        amountField.setFont(new Font("Arial", Font.PLAIN, 14));
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        frame.getContentPane().add(amountField, gbc);
        amountField.setColumns(10);

        JButton btnDeposit = new JButton("Deposit");
        btnDeposit.setFont(new Font("Arial", Font.PLAIN, 14));
        btnDeposit.setBackground(new Color(0, 204, 102));
        btnDeposit.setForeground(Color.WHITE);
        btnDeposit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleTransaction(true);
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        frame.getContentPane().add(btnDeposit, gbc);

        JButton btnWithdraw = new JButton("Withdraw");
        btnWithdraw.setFont(new Font("Arial", Font.PLAIN, 14));
        btnWithdraw.setBackground(new Color(204, 0, 0));
        btnWithdraw.setForeground(Color.WHITE);
        btnWithdraw.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                handleTransaction(false);
            }
        });
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.gridwidth = 1;
        frame.getContentPane().add(btnWithdraw, gbc);

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Arial", Font.PLAIN, 14));
        btnExit.setBackground(new Color(128, 128, 128));
        btnExit.setForeground(Color.WHITE);
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                frame.dispose();
            }
        });
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        frame.getContentPane().add(btnExit, gbc);

        // Adding icons to buttons - assuming icons are in the classpath
        try {
            btnCheckBalance.setIcon(loadIcon("/icons/check_balance.png"));
            btnDeposit.setIcon(loadIcon("/icons/deposit.png"));
            btnWithdraw.setIcon(loadIcon("/icons/withdraw.png"));
            btnExit.setIcon(loadIcon("/icons/exit.png"));
        } catch (Exception e) {
            System.err.println("Icon resource not found: " + e.getMessage());
        }

        frame.setVisible(true);
    }

    private ImageIcon loadIcon(String path) throws Exception {
        URL iconURL = getClass().getResource(path);
        if (iconURL != null) {
            return new ImageIcon(iconURL);
        } else {
            throw new Exception("Resource not found: " + path);
        }
    }

    private void handleTransaction(boolean isDeposit) {
        try {
            double amount = Double.parseDouble(amountField.getText());
            boolean success;
            if (isDeposit) {
                success = atm.deposit(amount);
                if (success) {
                    JOptionPane.showMessageDialog(frame, "Deposit of $" + amount + " successful.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Error: Invalid deposit amount.");
                }
            } else {
                success = atm.withdraw(amount);
                if (success) {
                    JOptionPane.showMessageDialog(frame, "Withdrawal of $" + amount + " successful.");
                } else {
                    JOptionPane.showMessageDialog(frame, "Error: Insufficient funds or invalid amount.");
                }
            }
            updateBalance();
            amountField.setText("");
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid number.");
        }
    }

    private void updateBalance() {
        balanceLabel.setText("Current Balance: $" + atm.checkBalance());
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    ATMGUI window = new ATMGUI();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
}
