import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class StudentGradeCalculatorUI {
    private static boolean isDarkMode = false;

    public static void main(String[] args) {
        JFrame frame = new JFrame("Student Grade Calculator");
        frame.setSize(400, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        frame.add(panel);
        placeComponents(panel);

        frame.setVisible(true);
    }

    private static void placeComponents(JPanel panel) {
        Font labelFont = new Font("Arial", Font.BOLD, 14);
        Color textColor = isDarkMode ? Color.WHITE : Color.BLACK;

        JLabel label = new JLabel("Enter the number of subjects:");
        label.setFont(labelFont);
        label.setForeground(textColor);
        panel.add(label);

        JTextField numSubjectsField = new JTextField(10);
        panel.add(numSubjectsField);

        JButton calculateButton = new JButton("Calculate");
        calculateButton.setBackground(isDarkMode ? Color.GREEN.darker() : Color.GREEN);
        calculateButton.setForeground(textColor);
        calculateButton.setFont(labelFont);
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateGrade(numSubjectsField);
            }
        });
        panel.add(calculateButton);

        JTextArea resultArea = new JTextArea(8, 30);
        resultArea.setFont(labelFont);
        resultArea.setForeground(textColor);
        panel.add(resultArea);

        JButton toggleModeButton = new JButton("Toggle Mode");
        toggleModeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                isDarkMode = !isDarkMode;
                updateUI(isDarkMode, panel, calculateButton, resultArea, label, numSubjectsField);
            }
        });
        panel.add(toggleModeButton);
    }

    private static void updateUI(boolean isDarkMode, JPanel panel, JButton calculateButton, JTextArea resultArea, JLabel label, JTextField numSubjectsField) {
        Color backgroundColor = isDarkMode ? Color.DARK_GRAY : Color.WHITE;
        Color textColor = isDarkMode ? Color.WHITE : Color.BLACK;

        panel.setBackground(backgroundColor);
        resultArea.setBackground(backgroundColor);
        resultArea.setForeground(textColor);
        label.setForeground(textColor);
        calculateButton.setBackground(isDarkMode ? Color.GREEN.darker() : Color.GREEN);
        calculateButton.setForeground(textColor);
        numSubjectsField.setForeground(textColor);
    }

    private static void calculateGrade(JTextField numSubjectsField) {
        int numSubjects = Integer.parseInt(numSubjectsField.getText());

        StringBuilder result = new StringBuilder();
        int totalMarks = 0;
        for (int i = 1; i <= numSubjects; i++) {
            String input = JOptionPane.showInputDialog("Enter marks obtained in subject " + i + ":");
            int marks = Integer.parseInt(input);
            totalMarks += marks;
        }

        double averagePercentage = (double) totalMarks / numSubjects;

        char grade;
        if (averagePercentage >= 90) {
            grade = 'A';
        } else if (averagePercentage >= 80) {
            grade = 'B';
        } else if (averagePercentage >= 70) {
            grade = 'C';
        } else if (averagePercentage >= 60) {
            grade = 'D';
        } else {
            grade = 'F';
        }

        result.append("\n----- Results -----");
        result.append("\nTotal Marks: ").append(totalMarks);
        result.append("\nAverage Percentage: ").append(averagePercentage).append("%");
        result.append("\nGrade: ").append(grade);

        JOptionPane.showMessageDialog(null, result.toString());
    }
}
