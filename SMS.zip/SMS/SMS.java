import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

// Student Class
class Student {
    private String name;
    private int rollNumber;
    private String grade;
    private String address;

    public Student(String name, int rollNumber, String grade, String address) {
        this.name = name;
        this.rollNumber = rollNumber;
        this.grade = grade;
        this.address = address;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRollNumber() {
        return rollNumber;
    }

    public void setRollNumber(int rollNumber) {
        this.rollNumber = rollNumber;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @Override
    public String toString() {
        return "Student [name=" + name + ", rollNumber=" + rollNumber + ", grade=" + grade + ", address=" + address + "]";
    }
}

// StudentManagementSystem Class
class StudentManagementSystem {
    private List<Student> students;
    private final String fileName = "students.txt";

    public StudentManagementSystem() {
        this.students = new ArrayList<>();
        loadStudentsFromFile();
    }

    public void addStudent(Student student) {
        students.add(student);
        saveStudentsToFile();
    }

    public void removeStudent(int rollNumber) {
        students.removeIf(student -> student.getRollNumber() == rollNumber);
        saveStudentsToFile();
    }

    public Student searchStudent(int rollNumber) {
        for (Student student : students) {
            if (student.getRollNumber() == rollNumber) {
                return student;
            }
        }
        return null;
    }

    public List<Student> getAllStudents() {
        return new ArrayList<>(students);
    }

    private void loadStudentsFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 4) { // Ensure valid data
                    String name = parts[0];
                    int rollNumber = Integer.parseInt(parts[1]);
                    String grade = parts[2];
                    String address = parts[3];
                    students.add(new Student(name, rollNumber, grade, address));
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading students from file: " + e.getMessage());
        }
    }

    private void saveStudentsToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (Student student : students) {
                writer.write(student.getName() + "," + student.getRollNumber() + "," + student.getGrade() + "," + student.getAddress());
                writer.newLine();
            }
        } catch (IOException e) {
            System.out.println("Error saving students to file: " + e.getMessage());
        }
    }
}

// GUI Class
public class SMS {
    private StudentManagementSystem sms = new StudentManagementSystem();
    private JFrame frame;
    private DefaultTableModel tableModel;
    private JTable studentTable;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SMS().createAndShowGUI());
    }

    private JButton createStyledButton(String text, String iconPath) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        try {
            button.setIcon(new ImageIcon(getClass().getResource(iconPath)));
        } catch (NullPointerException e) {
            System.out.println("Icon not found: " + iconPath);
        }
        button.setFocusPainted(false);
        button.setBackground(Color.BLACK); // Change button background color to black
        button.setForeground(Color.WHITE); // Change button text color to white
        button.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        return button;
    }
    
    private void createAndShowGUI() {
        try {
            // Apply FlatLaf Look and Feel
            UIManager.setLookAndFeel("com.formdev.flatlaf.FlatLightLaf");
        } catch (Exception e) {
            e.printStackTrace();
        }
    
        frame = new JFrame("Student Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 700);
        frame.setLocationRelativeTo(null);  // Center the window
        frame.setResizable(false);  // Prevent window resizing
        frame.setLayout(new BorderLayout());
    
        // Table setup
        String[] columnNames = {"Name", "Roll Number", "Grade", "Address"};
        tableModel = new DefaultTableModel(columnNames, 0);
        studentTable = new JTable(tableModel);
        customizeTable();
        frame.add(new JScrollPane(studentTable), BorderLayout.CENTER);
    
        // Header setup
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(Color.BLACK); // Change header background color to black
        headerPanel.setLayout(new BorderLayout());
    
        JLabel headerLabel = new JLabel("Student Management System", JLabel.CENTER);
        headerLabel.setFont(new Font("Arial", Font.BOLD, 20));
        headerLabel.setForeground(Color.WHITE); // Change header label text color to white
        headerPanel.add(headerLabel, BorderLayout.CENTER);
    
        frame.add(headerPanel, BorderLayout.NORTH);
    
        // Button panel setup
        JPanel buttonPanel = new JPanel(new GridBagLayout());
        buttonPanel.setBorder(new EmptyBorder(10, 10, 10, 10));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
    
        JButton addButton = createStyledButton("Add Student", "/icons/add.png");
        JButton removeButton = createStyledButton("Remove Student", "/icons/remove.png");
        JButton searchButton = createStyledButton("Search Student", "/icons/search.png");
        JButton displayButton = createStyledButton("Display All Students", "/icons/display.png");
        JButton exitButton = createStyledButton("Exit", "/icons/exit.png");
    
        addButton.addActionListener(e -> promptAddStudent());
        removeButton.addActionListener(e -> promptRemoveStudent());
        searchButton.addActionListener(e -> promptSearchStudent());
        displayButton.addActionListener(e -> displayAllStudents());
        exitButton.addActionListener(e -> System.exit(0));
    
        gbc.gridx = 0;
        gbc.gridy = 0;
        buttonPanel.add(addButton, gbc);
        gbc.gridx = 1;
        buttonPanel.add(removeButton, gbc);
        gbc.gridx = 2;
        buttonPanel.add(searchButton, gbc);
        gbc.gridx = 3;
        buttonPanel.add(displayButton, gbc);
        gbc.gridx = 4;
        buttonPanel.add(exitButton, gbc);
    
        frame.add(buttonPanel, BorderLayout.SOUTH);
        frame.setVisible(true);
    }
    
    

    private void customizeTable() {
        studentTable.setFont(new Font("Arial", Font.PLAIN, 14));
        studentTable.setRowHeight(25);
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setFont(new Font("Arial", Font.BOLD, 14));
        headerRenderer.setBackground(Color.BLACK);
        headerRenderer.setForeground(Color.WHITE);
        for (int i = 0; i < studentTable.getColumnCount(); i++) {
            studentTable.getColumnModel().getColumn(i).setHeaderRenderer(headerRenderer);
        }
    }

    private void promptAddStudent() {
        JTextField nameField = new JTextField();
        JTextField rollNumberField = new JTextField();
        JTextField gradeField = new JTextField();
        JTextField addressField = new JTextField();

        Object[] message = {
            "Name:", nameField,
            "Roll Number:", rollNumberField,
            "Grade:", gradeField,
            "Address:", addressField
        };

        int option = JOptionPane.showConfirmDialog(frame, message, "Add Student", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            try {
                String name = nameField.getText();
                int rollNumber = Integer.parseInt(rollNumberField.getText());
                String grade = gradeField.getText();
                String address = addressField.getText();

                Student student = new Student(name, rollNumber, grade, address);
                sms.addStudent(student);
                displayMessage("Student added successfully!");
                refreshTableData();
            } catch (NumberFormatException ex) {
                displayMessage("Invalid input for roll number. Please enter a valid integer.");
            }
        }
    }

    private void promptRemoveStudent() {
        String rollNumberStr = JOptionPane.showInputDialog(frame, "Enter roll number to remove:");
        if (rollNumberStr != null && !rollNumberStr.isEmpty()) {
            try {
                int rollNumber = Integer.parseInt(rollNumberStr);
                sms.removeStudent(rollNumber);
                displayMessage("Student removed successfully!");
                refreshTableData();
            } catch (NumberFormatException ex) {
                displayMessage("Invalid input for roll number. Please enter a valid integer.");
            }
        }
    }

    private void promptSearchStudent() {
        String rollNumberStr = JOptionPane.showInputDialog(frame, "Enter roll number to search:");
        if (rollNumberStr != null && !rollNumberStr.isEmpty()) {
            try {
                int rollNumber = Integer.parseInt(rollNumberStr);
                Student student = sms.searchStudent(rollNumber);
                if (student != null) {
                    displayMessage("Student found: " + student);
                } else {
                    displayMessage("Student not found.");
                }
            } catch (NumberFormatException ex) {
                displayMessage("Invalid input for roll number. Please enter a valid integer.");
            }
        }
    }

    private void displayAllStudents() {
        refreshTableData();
    }

    private void refreshTableData() {
        tableModel.setRowCount(0); // Clear existing data
        for (Student student : sms.getAllStudents()) {
            tableModel.addRow(new Object[]{student.getName(), student.getRollNumber(), student.getGrade(), student.getAddress()});
        }
    }

    private void displayMessage(String message) {
        JOptionPane.showMessageDialog(frame, message);
    }
}
