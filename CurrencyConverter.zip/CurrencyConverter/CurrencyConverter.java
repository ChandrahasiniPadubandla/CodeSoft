import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class CurrencyConverter {
    private JFrame frame;
    private JTextField amountField;
    private JComboBox<String> fromCurrency;
    private JComboBox<String> toCurrency;
    private JLabel resultLabel;

    private Map<String, Double> exchangeRates;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CurrencyConverter().createAndShowGUI());
    }

    public CurrencyConverter() {
        exchangeRates = new HashMap<>();
        // Example exchange rates; in a real application, these would be fetched from an API
        exchangeRates.put("USD/RUB", 64.52);
        exchangeRates.put("RUB/USD", 0.0155);
        exchangeRates.put("USD/EUR", 0.85);
        exchangeRates.put("EUR/USD", 1.18);
        exchangeRates.put("USD/GBP", 0.74);
        exchangeRates.put("GBP/USD", 1.35);
        exchangeRates.put("USD/INR", 73.5);
        exchangeRates.put("INR/USD", 0.0136);
        exchangeRates.put("USD/JPY", 110.0);
        exchangeRates.put("JPY/USD", 0.0091);
        exchangeRates.put("USD/CAD", 1.25);
        exchangeRates.put("CAD/USD", 0.80);
        exchangeRates.put("USD/AUD", 1.35);
        exchangeRates.put("AUD/USD", 0.74);
        // Add more exchange rates as needed
    }

    private void createAndShowGUI() {
        try {
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
        } catch (Exception e) {
            e.printStackTrace();
        }

        frame = new JFrame("Currency Converter");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(400, 300);
        frame.setLayout(new GridBagLayout());
        frame.getContentPane().setBackground(new Color(60, 63, 65)); // Set frame background color

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        Font font = new Font("Arial", Font.PLAIN, 14);
        Color textColor = Color.WHITE; // Set text color
        Color buttonColor = new Color(70, 130, 180);
        Color fieldColor = new Color(43, 43, 43);

        // Create GUI elements
        amountField = createTextField(font, textColor, fieldColor);
        String[] currencies = {"USD / Dollar", "RUB / Ruble", "EUR / Euro", "GBP / Pound", "INR / Rupee", "JPY / Yen", "CAD / Canadian Dollar", "AUD / Australian Dollar"};
        fromCurrency = createComboBox(currencies, font, textColor, fieldColor);
        toCurrency = createComboBox(currencies, font, textColor, fieldColor);
        JButton convertButton = createButton("Convert", font, buttonColor, textColor);
        resultLabel = createLabel("Result:", font, textColor);

        JLabel amountLabel = createLabel("Amount:", font, textColor);
        JLabel fromLabel = createLabel("From:", font, textColor);
        JLabel toLabel = createLabel("To:", font, textColor);

        // Set default selections
        fromCurrency.setSelectedIndex(0);
        toCurrency.setSelectedIndex(1);

        // Add elements to frame
        addToFrame(frame, amountLabel, gbc, 0, 0);
        addToFrame(frame, amountField, gbc, 1, 0);
        addToFrame(frame, fromLabel, gbc, 0, 1);
        addToFrame(frame, fromCurrency, gbc, 1, 1);
        addToFrame(frame, toLabel, gbc, 0, 2);
        addToFrame(frame, toCurrency, gbc, 1, 2);
        addToFrame(frame, convertButton, gbc, 0, 3, 2, GridBagConstraints.HORIZONTAL);
        addToFrame(frame, resultLabel, gbc, 0, 4, 2, GridBagConstraints.CENTER);

        convertButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                convertCurrency();
            }
        });

        frame.setVisible(true);
    }

    private JTextField createTextField(Font font, Color textColor, Color fieldColor) {
        JTextField textField = new JTextField(10);
        textField.setFont(font);
        textField.setForeground(textColor);
        textField.setBackground(fieldColor);
        textField.setBorder(BorderFactory.createCompoundBorder(
                textField.getBorder(),
                BorderFactory.createEmptyBorder(5, 5, 5, 5)));
        textField.setToolTipText("Enter the amount to convert");
        return textField;
    }

    private JComboBox<String> createComboBox(String[] items, Font font, Color textColor, Color fieldColor) {
        JComboBox<String> comboBox = new JComboBox<>(items);
        comboBox.setFont(font);
        comboBox.setForeground(textColor);
        comboBox.setBackground(fieldColor);
        comboBox.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                setForeground(Color.WHITE);
                setBackground(new Color(43, 43, 43));
                if (isSelected) {
                    setBackground(new Color(70, 130, 180));
                }
                return this;
            }
        });
        comboBox.setToolTipText("Select the currency");
        return comboBox;
    }

    private JButton createButton(String text, Font font, Color background, Color foreground) {
        JButton button = new JButton(text);
        button.setFont(font);
        button.setBackground(background);
        button.setForeground(foreground);
        return button;
    }

    private JLabel createLabel(String text, Font font, Color foreground) {
        JLabel label = new JLabel(text);
        label.setFont(font);
        label.setForeground(foreground);
        return label;
    }

    private void addToFrame(JFrame frame, Component comp, GridBagConstraints gbc, int x, int y) {
        addToFrame(frame, comp, gbc, x, y, 1, GridBagConstraints.NONE);
    }

    private void addToFrame(JFrame frame, Component comp, GridBagConstraints gbc, int x, int y, int width, int fill) {
        gbc.gridx = x;
        gbc.gridy = y;
        gbc.gridwidth = width;
        gbc.fill = fill;
        frame.add(comp, gbc);
    }

    private void convertCurrency() {
        try {
            double amount = Double.parseDouble(amountField.getText());
            String from = (String) fromCurrency.getSelectedItem();
            String to = (String) toCurrency.getSelectedItem();

            if (from == null || to == null) {
                resultLabel.setText("Please select currencies.");
                return;
            }

            String fromCode = from.split(" / ")[0];
            String toCode = to.split(" / ")[0];
            String conversionKey = fromCode + "/" + toCode;

            if (exchangeRates.containsKey(conversionKey)) {
                double rate = exchangeRates.get(conversionKey);
                double convertedAmount = amount * rate;
                resultLabel.setText(String.format("%.2f %s = %.2f %s", amount, fromCode, convertedAmount, toCode));
            } else {
                resultLabel.setText("Conversion rate not available.");
            }
        } catch (NumberFormatException e) {
            resultLabel.setText("Invalid amount.");
        }
    }
}
